module.exports = {
    content: [
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            primary: "#A78BFA",
            secondary: "#6D28D9",
            accent: "#F3E8FF",
            neutral: "#E5E7EB",
        },
    },
    plugins: [],
};